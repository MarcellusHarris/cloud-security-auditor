### Cloud Security Auditor TODOs

To finalise this repository for Agent Mode:

- [ ] **Sample reports:** Add example output files (`findings.csv`, `findings.json`, `findings.html`) under `examples/`.
- [ ] **Dry‑run flag:** Implement a `--dry-run` option in `auditor.py` and document how it works.
- [ ] **Read‑only policy:** Include a minimal IAM policy JSON (`policy-readonly.json`) demonstrating the required permissions for read‑only audits.
- [ ] **Screenshot:** Add an illustrative dashboard or report image (`assets/cloud-auditor-output.png`) and embed it in the README.
- [ ] **README:** Update with quick‑start instructions, permission requirements, and references to the sample reports.
