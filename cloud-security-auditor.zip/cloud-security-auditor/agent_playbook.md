# Agent Playbook for Cloud Security Auditor

1. **Dry‑run and formats:** Ensure that the auditor script supports a `--dry-run` option and can output CSV, JSON and HTML. Update the examples when output formats change.
2. **Permissions:** Verify that the IAM policy in `examples/policy-readonly.json` remains sufficient for read‑only audits across supported services. Update as new AWS services are scanned.
3. **Reports:** Run the auditor against a test account to generate real reports and compare them against the examples in `/examples/`.
4. **Documentation:** Keep the README clear about setup, required permissions and the purpose of each format. Refresh the illustrative screenshot when UI improvements are made.
5. **Issues:** Track enhancements such as multi-cloud support, additional checks or integration with ticketing systems.
