## Cloud Security Auditor

This tool scans your cloud environment for common misconfigurations such as overly permissive IAM users and policies, publicly accessible storage buckets, and other risks. It can output findings in CSV, JSON or HTML formats and includes a `--dry-run` flag to enumerate resources without taking any actions.

### Quick Start

Run an audit in dry‑run mode and write results as CSV:

```bash
python auditor.py --format csv --output findings.csv --dry-run
```

Specify `--format json` or `--format html` to produce other formats. Sample reports are provided under `examples/` (`findings.csv`, `findings.json`, `findings.html`).

### IAM permissions

The script should be run with read‑only credentials. A minimal policy is included at `examples/policy-readonly.json`; attach it to the IAM role or user executing the audit. The policy grants only the `Describe` and `List` permissions required for enumeration.

### Visualization

For a quick visual overview of the results, open the HTML report or refer to the illustrative dashboard image below.

![Cloud Auditor Output](assets/cloud-auditor-output.png)
